import React, { useState } from 'react';
import axios from 'axios';

function AddArticle() {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [dateCreated, setDateCreated] = useState('');
  const [creatorName, setCreatorName] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post('/articles', { name, category, dateCreated, creatorName });
      setName('');
      setCategory('');
      setDateCreated('');
      setCreatorName('');
      setMessage('Article added successfully!');
    } catch (error) {
      console.error(error);
      setMessage('Error adding article. Please try again.');
    }
  };

  return (
    <div className="container cl-5">
      <h1>Add Article</h1>
      <form onSubmit={handleSubmit}>
        <div className="nm-3">
          <label htmlFor="name" className="form-label">Name</label>
          <input type="text" className="form-control" id="name" value={name} onChange={(event) => setName(event.target.value)} required />
        </div>
        <div className="nm-3">
          <label htmlFor="category" className="form-label">Category</label>
          <select className="form-select" id="category" value={category} onChange={(event) => setCategory(event.target.value)} required>
            <option value="">Select a category</option>
            <option value="painting">Painting</option>
            <option value="sculpture">Sculpture</option>
            <option value="artifact">Artifact</option>
          </select>
        </div>
        <div className="nm-3">
          <label htmlFor="dateCreated" className="form-label">Date Created</label>
          <input type="date" className="form-control" id="dateCreated" value={dateCreated} onChange={(event) => setDateCreated(event.target.value)} required />
        </div>
        <div className="nm-3">
          <label htmlFor="creatorName" className="form-label">Creator Name</label>
          <input type="text" className="form-control" id="creatorName" value={creatorName} onChange={(event) => setCreatorName(event.target.value)} required />
        </div>
        <button type="submit" className="btn btn-primary">Add Article</button>
      </form>
      {message && <div className="alert alert-info mt-3">{message}</div>}
    </div>
  );
}