import React from 'react';

function Home() {
  return (
    <div className="container cl-5">
      <h1>Welcome to Museum Management</h1>
      <p>Manage your museum's articles with ease.</p>
    </div>
  );
}