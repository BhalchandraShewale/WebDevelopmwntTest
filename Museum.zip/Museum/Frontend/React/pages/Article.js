import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ArticleTable from '../components/ArticleTable';

function Articles() {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    axios.get('/articles')
      .then(response => setArticles(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <div className="container my-5">
      <h1>Articles</h1>
      <ArticleTable articles={articles} />
    </div>
  );
}