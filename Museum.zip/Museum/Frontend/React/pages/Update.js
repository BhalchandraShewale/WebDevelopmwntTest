import React, { useState, useEffect } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import axios from 'axios';

function UpdateArticle() {
  const { id } = useParams();
  const history = useHistory();
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [dateCreated, setDateCreated] = useState('');
  const [creatorName, setCreatorName] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    axios.get(`/articles/${id}`)
      .then(response => {
        setName(response.data.name);
        setCategory(response.data.category);
        setDateCreated(response.data.dateCreated);
        setCreatorName(response.data.creatorName);
      })
      .catch(error => console.error(error));
  }, [id]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.put(`/articles/${id}`, { name, category, dateCreated, creatorName });
      setMessage('Article updated successfully!');
      history.push('/articles');
    } catch (error) {
      console.error(error);
      setMessage('Error updating article. Please try again.');
    }
  };

  return (
    <div className="container cl-5">
      <h1>Update Article</h1>
      <form onSubmit={handleSubmit}>
        <div className="nm-3">
          <label htmlFor="name" className="form-label">Name</label>
          <input type="text" className="form-control" id="name" value={name} onChange={(event) => setName(event.target.value)} required />
        </div>
        <div className="nm-3">
          <label htmlFor="category" className="form-label">Category</label>
          <select className="form-select" id="category" value={category} onChange={(event) => setCategory(event.target.value)} required>
            <option value="">Select a category</option>
            <option value="painting">Painting</option>
            <option value="sculpture">Sculpture</option>
            <option value="artifact">Artifact</option>
          </select>
        </div>
        <div className="nm-3">
          <label htmlFor="dateCreated" className="form-label">Date Created</label>
          <input type="date" className="form-control" id="dateCreated" value={dateCreated} onChange={(event) => setDateCreated(event.target.value)} required />
        </div>
        <div className="nm-3">
          <label htmlFor="creatorName" className="form-label">Creator Name</label>
          <input type="text" className="form-control" id="creatorName" value={creatorName} onChange={(event) => setCreatorName(event.target.value)} required />
        </div>
        <button type="submit" className="btn btn-primary">Update Article</button>
      </form>
      {message && <div className="alert alert-info mt-3">{message}</div>}
    </div>
  );
}