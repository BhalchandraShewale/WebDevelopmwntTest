const express = require('express');
const Article = require('../models/Article');

const router = express.Router();

// Add an article
router.post('/', async (req, res) => {
  try {
    const { name, category, dateCreated, creatorName } = req.body;
    const article = new Article({ name, category, dateCreated, creatorName });
    await article.save();
    res.status(201).json(article);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Get all articles
router.get('/', async (req, res) => {
  try {
    const articles = await Article.find();
    res.json(articles);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update an article
router.put('/:id', async (req, res) => {
  try {
    const { name, category, dateCreated, creatorName } = req.body;
    const article = await Article.findByIdAndUpdate(
      req.params.id,
      { name, category, dateCreated, creatorName },
      { new: true }
    );
    if (!article) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json(article);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});